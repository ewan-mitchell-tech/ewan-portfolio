import type { NextApiRequest, NextApiResponse } from 'next'
import chromium from '@sparticuz/chromium'
import puppeteer from 'puppeteer-core'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { url, filename = 'Ewan_Mitchell_CV.pdf' } = req.query
    if (!url || typeof url !== 'string') {
      res.status(400).json({ error: 'Missing ?url=' })
      return
    }

    const executablePath = await chromium.executablePath()
    const browser = await puppeteer.launch({
      args: [...chromium.args, '--no-sandbox', '--disable-setuid-sandbox'],
      defaultViewport: chromium.defaultViewport,
      executablePath,
      headless: chromium.headless
    })
    const page = await browser.newPage()
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 })
    const pdf = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '12mm', right: '12mm', bottom: '12mm', left: '12mm' }
    })
    await browser.close()

    res.setHeader('Content-Type', 'application/pdf')
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`)
    res.send(pdf)
  } catch (err: any) {
    console.error(err)
    res.status(500).json({ error: 'Failed to render PDF', detail: String(err?.message || err) })
  }
}
