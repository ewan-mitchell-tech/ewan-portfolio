  'use client';
  import { useEffect, useMemo, useState } from 'react';

  const INDUSTRY_RULES = [
    {pattern:/security|soc|siem|splunk|defen(c|s)e|cyber|pentest|red team|blue team/i, industry:'Cyber Security'},
    {pattern:/kubernetes|terraform|jenkins|ci\/cd|helm|docker|iac|sre|platform/i, industry:'DevOps & Cloud'},
    {pattern:/windows|linux|intune|mecm|office 365|exchange|active directory|endpoint|sccm/i, industry:'System Administration'},
    {pattern:/help ?desk|service ?desk|support|ticket|sla/i, industry:'Service Desk / IT Support'},
    {pattern:/power bi|tableau|data studio|sql|analytics|bi|dashboard/i, industry:'Data & BI'},
    {pattern:/cad|solidworks|autocad|design|manufactur|electronic/i, industry:'CAD & Tech Design'},
    {pattern:/consult|strategy|pm|prince2|six sigma|agile/i, industry:'Consulting'},
  ];

  const COUNTRY_HINTS:any = {
    UK: { greeting: (l:string)=> l.startsWith('de') ? 'Sehr geehrtes Recruiting-Team' : l.startsWith('fr') ? 'Bonjour équipe de recrutement' : l.startsWith('es') ? 'Estimado equipo de contratación' : l.startsWith('pt') ? 'Prezada Equipe de Recrutamento' : l.startsWith('nl') ? 'Geacht Recruitmentteam' : l.startsWith('el') ? 'Αξιότιμη Ομάδα Προσλήψεων' : l.startsWith('ar') ? 'فريق التوظيف المحترم' : l.startsWith('zh') ? '尊敬的招聘团队' : l.startsWith('ja') ? '採用ご担当者様' : l.startsWith('ko') ? '채용 담당자님께' : l.startsWith('sw') ? 'Waheshimiwa Timu ya Ajira' : l.startsWith('xh') ? 'Bafazi beQesha abahloniphekileyo' : l.startsWith('tl') ? 'Mahal na Hiring Team' : l.startsWith('id') ? 'Yth. Tim Rekrutmen' : l.startsWith('ms') ? 'Kepada Pasukan Pengambilan Pekerja' : l.startsWith('hi') ? 'आदरणीय भर्ती टीम' : l.startsWith('la') ? 'Turma conductionis honoranda' : l.startsWith('ki') ? 'Wĩtũmĩti wa Kũrehia ũhonokie' : 'Dear Hiring Team', locale: 'UK', spellings: 'UK' },
    US: { greeting: (l:string)=> l.startsWith('de') ? 'Sehr geehrtes Recruiting-Team' : l.startsWith('fr') ? 'Bonjour équipe de recrutement' : l.startsWith('es') ? 'Estimado equipo de contratación' : l.startsWith('pt') ? 'Prezada Equipe de Recrutamento' : l.startsWith('nl') ? 'Geacht Recruitmentteam' : l.startsWith('el') ? 'Αξιότιμη Ομάδα Προσλήψεων' : l.startsWith('ar') ? 'فريق التوظيف المحترم' : l.startsWith('zh') ? '尊敬的招聘团队' : l.startsWith('ja') ? '採用ご担当者様' : l.startsWith('ko') ? '채용 담당자님께' : l.startsWith('sw') ? 'Waheshimiwa Timu ya Ajira' : l.startsWith('xh') ? 'Bafazi beQesha abahloniphekileyo' : l.startsWith('tl') ? 'Mahal na Hiring Team' : l.startsWith('id') ? 'Yth. Tim Rekrutmen' : l.startsWith('ms') ? 'Kepada Pasukan Pengambilan Pekerja' : l.startsWith('hi') ? 'आदरणीय भर्ती टीम' : l.startsWith('la') ? 'Turma conductionis honoranda' : l.startsWith('ki') ? 'Wĩtũmĩti wa Kũrehia ũhonokie' : 'Dear Hiring Team', locale: 'US', spellings: 'US' },
    DE: { greeting: 'Sehr geehrtes Recruiting-Team', locale: 'DE', spellings: 'EN' },
    FR: { greeting: 'Bonjour équipe de recrutement', locale: 'FR', spellings: 'EN' }
  };

  function guessIndustry(text:string){
    for (const r of INDUSTRY_RULES){
      if (r.pattern.test(text)) return r.industry;
    }
    return 'General IT';
  }

  function pickCv(industry:string){
    const map:any = {
      'Cyber Security': {name:'Cyber CV', file:'/cv/CV Cyber.pdf'},
      'DevOps & Cloud': {name:'DevOps CV', file:'/cv/Ewan_Mitchell_General_IT_CV.docx'},
      'System Administration': {name:'System Admin CV', file:'/cv/Ewan_Mitchell_System_Admin_CV.docx'},
      'Service Desk / IT Support': {name:'Service Desk CV', file:'/cv/Ewan_Mitchell_Service_Desk_CV_Updated.docx'},
      'Data & BI': {name:'Data & BI CV', file:'/cv/Ewan_Mitchell_General_IT_CV.docx'},
      'CAD & Tech Design': {name:'CAD Engineer CV', file:'/cv/Ewan_Mitchell_CAD_Engineer_CV.docx'},
      'Consulting': {name:'Harvard/Consulting CV', file:'/cv/Ewan_Mitchell_Harvard_Style_CV.docx'},
      'General IT': {name:'General IT CV', file:'/cv/Ewan_Mitchell_General_IT_CV.docx'}
    };
    return map[industry] || map['General IT'];
  }

  export default function Recruiter(){
    const [company,setCompany]=useState('');
    const [country,setCountry]=useState('');
    const [role,setRole]=useState('');
    const [lang,setLang]=useState('en-UK');
    const [jd,setJd]=useState('');
    const industry = useMemo(()=>{
      const text = (company+' '+role+' '+jd);
      return guessIndustry(text);
    },[company,role,jd]);

    const cv = pickCv(industry);

    const generateLetter = ()=>{
      const c = country.trim().toUpperCase() || 'UK';
      const hints = COUNTRY_HINTS[c] || COUNTRY_HINTS['UK'];
      const today = new Date().toLocaleDateString();
      const body = `
${hints.greeting},

`+
        `I’m applying for the ${role || '{{JobTitle}}'} role at ${company || '{{CompanyName}}'}. `+
        `With a background in ${industry}, hands-on experience across Azure/AWS, Linux & Windows administration, endpoint management (Intune/MECM), and certifications including CCNA, CEH, Security+, and Azure AZ-104/AZ-900, I deliver secure, reliable, and automated solutions.\n\n`+
        `Highlights:\n`+
        `• Built dashboards (Power BI) and automated infrastructure with Terraform/Jenkins/Docker.\n`+
        `• Tier 1–3 support, AD, identity, and device hardening; scripted in Python/PowerShell/Bash.\n`+
        `• Cyber security practices: secure auth, input validation, encryption, IDS/Firewalls.\n\n`+
        `I’m keen to bring this blend of DevOps, SysAdmin, and Security to ${company || 'your organization'}. `+
        `Thank you for your time.\n\nSincerely,\nEwan Mitchell\n`;

      const blob = new Blob([body], {type:'text/plain'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Ewan_Mitchell_Cover_Letter_${(role||industry||'General').replace(/\s+/g,'_')}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    };

    const submit = async(e:any)=>{
      e.preventDefault();
      const res = await fetch('/api/recommend',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({company,role,jd,country,industry})
      });
      const data = await res.json();
      console.log('Recommendation', data);
      // fire-and-forget tracking
      fetch('/api/track',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({event:'recruiter_submit',company,role,country,industry,cv:data?.bestCV,ts:Date.now()})});
      alert(`Recommended: ${data.bestCV}`);
    };

    return (
      <div>
        <h1>Recruiter Portal</h1>
        <p>Choose style and language. Originals are your uploaded DOCX/PDFs. Branded versions are ATS-optimized HTML ready for quick export.</p>
        <form onSubmit={submit} className="grid" style={{gridTemplateColumns:'1fr 1fr', gap:16}}>
          <input placeholder="Company" value={company} onChange={e=>setCompany(e.target.value)} />
          <input placeholder="Country (e.g., UK, US, DE)" value={country} onChange={e=>setCountry(e.target.value)} />
          <input placeholder="Role Title" value={role} onChange={e=>setRole(e.target.value)} />
          <textarea style={{gridColumn:'1/-1', minHeight:140}} placeholder="Paste Job Description (optional)" value={jd} onChange={e=>setJd(e.target.value)} />
          <input type="hidden" id="lang_state" value={lang} />
          <div style={{gridColumn:'1/-1'}}>
            <div className="badge">Detected Industry: {industry}</div>
            <div className="badge">Suggested CV: {cv.name}</div>
          </div>
          
    <div style={{gridColumn:'1/-1', display:'flex', gap:12, alignItems:'center'}}>
      <label><input type="radio" name="style" defaultChecked value="original" onChange={()=>{}}/> Original</label>
      <label><input type="radio" name="style" value="branded" onChange={()=>{}}/> Branded ATS</label>
      <select id="lang" onChange={(e)=>setLang((e.target as HTMLSelectElement).value)} value={lang}>
        <option value="en-UK">English (UK)</option>
        <option value="en-US">English (US)</option>
        <option value="de-DE">Deutsch</option>
        <option value="fr-FR">Français</option>
        <option value="es-ES">Español</option>
        <option value="pt-PT">Português</option>
        <option value="nl-NL">Nederlands</option>
        <option value="el-GR">Ελληνικά</option>
        <option value="ar">العربية</option>
        <option value="zh-CN">中文 (简体)</option>
        <option value="ja-JP">日本語</option>
        <option value="ko-KR">한국어</option>
        <option value="sw-KE">Kiswahili</option>
        <option value="xh-ZA">isiXhosa</option>
        <option value="tl-PH">Tagalog</option>
        <option value="id-ID">Bahasa Indonesia</option>
        <option value="ms-MY">Bahasa Melayu</option>
        <option value="hi-IN">हिन्दी</option>
        <option value="la">Latina</option>
        <option value="ki-KE">Gĩkũyũ</option>
      </select>
    </div>
    <div style={{display:'flex', gap:12, gridColumn:'1/-1'}}>
    

            <a className="btn" href={cv.file} target="_blank">Download CV (Original)</a>
            <button type="button" className="btn" onClick={()=>{
              const styleSel = (document.querySelector('input[name=style]:checked') as HTMLInputElement)?.value || 'original';
              if(styleSel==='branded'){
                const map:any = {
                  'Cyber Security': '/cv/branded/Cyber_CV.html',
                  'DevOps & Cloud': '/cv/branded/DevOps_CV.html',
                  'System Administration': '/cv/branded/SystemAdmin_CV.html',
                  'Service Desk / IT Support': '/cv/branded/ServiceDesk_CV.html',
                  'Data & BI': '/cv/branded/DataBI_CV.html',
                  'CAD & Tech Design': '/cv/branded/CAD_CV.html',
                  'Consulting': '/cv/branded/Consulting_CV.html',
                  'General IT': '/cv/branded/Master_IT_CV.html'
                };
                const url = map[industry] || map['General IT'];
                window.open(url + '?c='+encodeURIComponent(company)+'&r='+encodeURIComponent(role)+'&co='+encodeURIComponent(country)+'&lang='+encodeURIComponent(lang),'_blank');
              (window as any)._lastBrandedUrl = url + '?c='+encodeURIComponent(company)+'&r='+encodeURIComponent(role)+'&co='+encodeURIComponent(country)+'&lang='+encodeURIComponent(lang);
              } else {
                alert('Switch to Branded ATS to view the on-brand version.');
              }
            }}>Open Branded CV</button>
    
            <button type="button" className="btn" onClick={()=>{
              const branded = (window as any)._lastBrandedUrl;
              const href = '/api/export-pdf?url=' + encodeURIComponent(branded || (location.origin + '/cv/branded/Master_IT_CV.html')) + '&filename=' + encodeURIComponent('Ewan_Mitchell_CV.pdf');
              window.open(href, '_blank');
            }}>Export Branded as PDF</button>
        
    
            <button type="button" className="btn" onClick={generateLetter}>Generate Personalized Cover Letter</button>
    
            <button type="button" className="btn" onClick={()=>{
              const branded = (window as any)._lastBrandedUrl;
              const href = '/api/export-pdf?url=' + encodeURIComponent(branded || (location.origin + '/cv/branded/Master_IT_CV.html')) + '&filename=' + encodeURIComponent('Ewan_Mitchell_CV.pdf');
              window.open(href, '_blank');
            }}>Export Branded as PDF</button>
        
            <button className="btn" type="submit">Save & Log</button>
    
            <button type="button" className="btn" onClick={()=>{
              const branded = (window as any)._lastBrandedUrl;
              const href = '/api/export-pdf?url=' + encodeURIComponent(branded || (location.origin + '/cv/branded/Master_IT_CV.html')) + '&filename=' + encodeURIComponent('Ewan_Mitchell_CV.pdf');
              window.open(href, '_blank');
            }}>Export Branded as PDF</button>
        
          </div>
        </form>
      </div>
    );
  }
