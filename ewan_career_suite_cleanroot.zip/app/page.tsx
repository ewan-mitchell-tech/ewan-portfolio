
export default function Page() {
  return (
    <div style={{padding:24}}>
      <h1>Ewan Mitchell — Portfolio & Recruiter Portal</h1>
      <p>Welcome! This is my interactive portfolio, recruiter portal, and CV showcase.</p>
      <ul>
        <li><a href="/cv">CV Library</a></li>
        <li><a href="/recruiter">Recruiter Portal</a></li>
        <li><a href="/projects">Projects & Demos</a></li>
      </ul>
    </div>
  );
}
