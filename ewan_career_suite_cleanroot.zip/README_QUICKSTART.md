
# 🚀 Ewan Career Suite — Quickstart

## Prerequisites
- Node.js v18+ installed
- GitHub account
- Vercel account (free)

## Setup (20 minutes)
```bash
unzip ewan_career_suite.zip
cd career-suite-next
npm install
npm run dev   # local preview at http://localhost:3000
```

## Deploy to Vercel
1. Push this folder to GitHub (`ewan-career-suite`).
2. In Vercel, click **New Project** → import from GitHub.
3. Add environment variables (see `.env.example`).
4. Deploy → site goes live globally.

## Key Pages
- `/` → Home
- `/recruiter` → Recruiter Portal (auto CV recommendation)
- `/compare` → Compare CVs
- `/timeline` → Career Timeline + Board Pack
- `/projects` → Projects & Demos
- `/contact` → Contact Form

## Files
- CVs in `/public/cv`
- Board Pack demo: `/public/assets/board-pack.html`
- Timeline PDF: `/public/assets/timeline.pdf`
- Logs: `/data/events.jsonl`, `/data/contacts.jsonl`



---

## Originals vs Branded ATS
- **Originals**: Your uploaded DOCX/PDF CVs and cover letters in `/public/cv`.
- **Branded ATS**: HTML-based CVs in `/public/cv/branded` that auto-fill placeholders and are ATS-optimized.
- Use the **Recruiter Portal** to switch styles and auto-personalize by Company, Role, Country and detected Industry.

## Localization
- Cover letters and branded CV headings can be auto-translated by integrating a translation API (optional).
- Language selector on `/recruiter` preps the pack per region (EN-UK/EN-US/DE/FR/ES).

## Exporting Branded to PDF/DOCX
- By default, Branded pages open as HTML. To export to PDF on Vercel, add a headless renderer (e.g., Playwright).
- A serverless function can render the Branded page URL to PDF and stream back to the user.


## One-click PDF Export (Serverless)
- API: `/api/export-pdf?url=<public-branded-url>&filename=<name>.pdf`
- Uses `@sparticuz/chromium` + `puppeteer-core`, Vercel-compatible.
- The Recruiter Portal adds a button **Export Branded as PDF** automatically.
